<footer class="main-footer">
	<div class="pull-right hidden-xs">
		<b>MYXZLPLTK</b>
	</div>
	<strong>Hak Cipta &copy; <?= date("Y") ?> <a href="#">Tulungagung Cyber Link</a>.</strong>
</footer>